#!/bin/env python

import sys
import os

from xml.sax import handler, make_parser

import re

class IconCoverageLinkHandler(handler.ContentHandler):
    def __init__(self):
        self.inIcon = False
        self.inLink = False
        self.mapping = {}

    def startElement(self, name, attributes):
        if name == "context":
            self.Context = attributes["dir"]

        elif name == "icon":
            self.inIcon = True
            self.IconName = attributes["name"]
        elif name == "link":
            self.inLink = True

    def characters(self, content):
        if self.inLink:
            if not self.mapping.has_key(self.Context):
                self.mapping[self.Context] = []

            self.mapping[self.Context].append((self.IconName, content))

    def endElement(self, name):
        if name == "icon":
            self.inIcon = False

        elif name == "link":
            self.inLink = False

def create_symlinks(base_dir, dirs, gtk_tool_links):
    for category in gtk_tool_links.keys():
        #make sure we see at least one of each icon listed.
	#if not it means we have a link to a nonexistent icon
        icon_ref_count = {}
        for size in dirs:
            base_size_dir = os.path.join(base_dir, "%ix%i"%(size,size))
 
            dir = os.path.join(base_size_dir, category)
        
            links = gtk_tool_links[category]
            for (icon, link) in links:
                s = os.path.split(link)
                filename = s[1]
                link_dir = s[0]
                c = filename.split('.')
                if len(c) > 1:
                    icon = "%s.%s"%(icon, c[-1])

                if not icon_ref_count.has_key(icon):
		    icon_ref_count[icon] = 0

                path_to_icon = os.path.join(dir, icon)
                if os.path.isfile(path_to_icon):
		    icon_ref_count[icon]+=1
		    print "file exists " + path_to_icon
                    cur_dir = os.getcwd()
                    full_link_dir = os.path.abspath(os.path.join(dir, link_dir))
                    if not os.path.isdir(full_link_dir):
                        os.mkdir(full_link_dir)
                   
                    os.chdir(full_link_dir)

                    rel_dir = icon 
                    if full_link_dir != dir:
                        rel_dir = '..'
                        s = os.path.split(full_link_dir)
                        while s[0] != base_size_dir:
                            rel_dir = os.path.join(rel_dir, '..')
                            s = os.path.split(s[0])
   
                        rel_dir = os.path.join(rel_dir, category, icon) 
                   
                    print "symlinking %s to %s"%(rel_dir, filename)
                    if os.path.islink(filename):
		        os.unlink(filename)

		    os.symlink(rel_dir, filename)
                    os.chdir(cur_dir)

        for icon in icon_ref_count.keys():
	    if not icon_ref_count[icon] > 0:
	        raise IOError("Icon '%s' of category '%s' does not exist and can not be linked to"%(icon, category))

def main(argv):
    base_dir = argv[1]
    links_xml = argv[2]

    parser = make_parser()
    link_mapping_handler = IconCoverageLinkHandler()
    parser.setContentHandler(link_mapping_handler)
    parser.parse(links_xml)

    size_dirs = [16, 20, 24, 32, 36, 48, 64, 96]

    create_symlinks(base_dir, size_dirs, link_mapping_handler.mapping)

main(sys.argv)
